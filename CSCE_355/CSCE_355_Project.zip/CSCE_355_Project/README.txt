Jack Primiani
April 22nd 2020
CSCE 355
Prof. Buell

Programs written:

Simulating a DFA. 
After reading the description of a DFA D from a text file, read any number of strings over D’s alphabet from another text file, indicating (to standard output) whether D accepts or rejects eachof the strings.

Text search. 
Read a string w from a text file, and write to standard output the description of a DFA that accepts a string x if and only if w is a substring of x.

